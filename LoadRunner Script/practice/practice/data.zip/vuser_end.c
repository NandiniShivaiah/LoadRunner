vuser_end()
{

	/* back */

	return 0;
}